<?php
session_start();
require_once 'koneksi.php';

// Pastikan user sudah login (Semua role boleh masuk ke halaman ini)
if (!isset($_SESSION['role'])) {
    header("Location: login.php");
    exit;
}

$role = $_SESSION['role'];
$username = $_SESSION['username'];

// Ambil data barang dari database
$query = "SELECT * FROM data_barang ORDER BY id DESC";
$result = mysqli_query($koneksi, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistem Pendataan</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-50 min-h-screen flex flex-col justify-between">

    <!-- Navbar -->
    <nav class="bg-slate-800 text-white px-6 py-4 flex justify-between items-center shadow">
        <h1 class="text-xl font-bold">Dashboard <?= ucfirst($role); ?></h1>
        <div class="flex items-center gap-4">
            <span class="text-sm bg-blue-600 px-3 py-1 rounded-full">Halo, <?= htmlspecialchars($username); ?> (<?= ucfirst($role); ?>)</span>
            <a href="logout.php" class="bg-red-500 hover:bg-red-600 text-sm px-3 py-1 rounded transition">Logout</a>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="max-w-5xl w-full mx-auto mt-8 p-6 bg-white rounded-lg shadow-sm mb-auto">
        <div class="flex justify-between items-center mb-6">
            <div>
                <h2 class="text-2xl font-bold text-slate-800">Data Barang</h2>
                <p class="text-sm text-slate-500">
                    <?php if ($role === 'admin'): ?>
                        Anda memiliki hak akses penuh (CRUD) ke sistem.
                    <?php else: ?>
                        Anda masuk sebagai **<?= ucfirst($role); ?>** (Hanya dapat melihat data).
                    <?php endif; ?>
                </p>
            </div>

            <!-- TOMBOL TAMBAH HANYA MUNCUL UNTUK ADMIN -->
            <?php if ($role === 'admin'): ?>
                <a href="tambah.php" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition shadow-sm">+ Tambah Data</a>
            <?php endif; ?>
        </div>

        <!-- Tabel Data -->
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse border border-slate-200">
                <thead>
                    <tr class="bg-slate-100 text-slate-700 text-sm">
                        <th class="p-3 border text-center w-12">No</th>
                        <th class="p-3 border">Nama Barang</th>
                        <th class="p-3 border">Stok</th>
                        <th class="p-3 border">Harga</th>
                        <!-- KOLOM AKSI HANYA MUNCUL JIKA ADMIN -->
                        <?php if ($role === 'admin'): ?>
                            <th class="p-3 border text-center w-36">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody class="text-sm">
                    <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr class="hover:bg-slate-50 text-slate-800">
                        <td class="p-3 border text-center"><?= $no++; ?></td>
                        <td class="p-3 border font-medium"><?= htmlspecialchars($row['nama_barang']); ?></td>
                        <td class="p-3 border"><?= $row['stok']; ?></td>
                        <td class="p-3 border">Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                        
                        <!-- TOMBOL AKSI CRUD HANYA MUNCUL JIKA ADMIN -->
                        <?php if ($role === 'admin'): ?>
                            <td class="p-3 border text-center space-x-1">
                                <a href="edit.php?id=<?= $row['id']; ?>" class="inline-block bg-amber-500 hover:bg-amber-600 text-white px-3 py-1 rounded text-xs transition">Edit</a>
                                <a href="hapus.php?id=<?= $row['id']; ?>" onclick="return confirm('Yakin ingin menghapus data ini?')" class="inline-block bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-xs transition">Hapus</a>
                            </td>
                        <?php endif; ?>
                    </tr>
                    <?php endwhile; ?>
                    <?php if (mysqli_num_rows($result) === 0): ?>
                    <tr>
                        <td colspan="<?= ($role === 'admin') ? 5 : 4; ?>" class="p-4 text-center text-slate-400">Belum ada data tersedia.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-slate-800 text-slate-400 text-center py-4 text-sm mt-8">
        &copy; 2026 Sistem Pendataan Native PHP. All rights reserved.
    </footer>

</body>
</html>