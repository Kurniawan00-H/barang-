<?php
session_start();
require_once 'koneksi.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (isset($_POST['simpan'])) {
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
    $stok = (int)$_POST['stok'];
    $harga = (int)$_POST['harga'];

    $query = "INSERT INTO data_barang (nama_barang, stok, harga) VALUES ('$nama', '$stok', '$harga')";
    if (mysqli_query($koneksi, $query)) {
        header("Location: admin.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Data Barang</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 flex items-center justify-center min-h-screen">
    <div class="w-full max-w-lg bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-bold mb-4">Tambah Data Barang</h2>
        <form method="POST">
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-1">Nama Barang</label>
                <input type="text" name="nama_barang" required class="w-full px-3 py-2 border rounded-lg">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-1">Stok</label>
                <input type="number" name="stok" required class="w-full px-3 py-2 border rounded-lg">
            </div>
            <div class="mb-6">
                <label class="block text-sm font-semibold mb-1">Harga</label>
                <input type="number" name="harga" required class="w-full px-3 py-2 border rounded-lg">
            </div>
            <div class="flex gap-2">
                <button type="submit" name="simpan" class="bg-green-600 text-white px-4 py-2 rounded-lg">Simpan</button>
                <a href="admin.php" class="bg-gray-400 text-white px-4 py-2 rounded-lg">Batal</a>
            </div>
        </form>
    </div>
</body>
</html>