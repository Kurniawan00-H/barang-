<?php
session_start();
require_once 'koneksi.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$id = (int)$_GET['id'];
$query = "SELECT * FROM data_barang WHERE id = $id";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
    $stok = (int)$_POST['stok'];
    $harga = (int)$_POST['harga'];

    $update_query = "UPDATE data_barang SET nama_barang='$nama', stok='$stok', harga='$harga' WHERE id=$id";
    if (mysqli_query($koneksi, $update_query)) {
        header("Location: admin.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Barang</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 flex items-center justify-center min-h-screen">
    <div class="w-full max-w-lg bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-bold mb-4">Edit Data Barang</h2>
        <form method="POST">
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-1">Nama Barang</label>
                <input type="text" name="nama_barang" value="<?= htmlspecialchars($data['nama_barang']); ?>" required class="w-full px-3 py-2 border rounded-lg">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-1">Stok</label>
                <input type="number" name="stok" value="<?= $data['stok']; ?>" required class="w-full px-3 py-2 border rounded-lg">
            </div>
            <div class="mb-6">
                <label class="block text-sm font-semibold mb-1">Harga</label>
                <input type="number" name="harga" value="<?= $data['harga']; ?>" required class="w-full px-3 py-2 border rounded-lg">
            </div>
            <div class="flex gap-2">
                <button type="submit" name="update" class="bg-blue-600 text-white px-4 py-2 rounded-lg">Update</button>
                <a href="admin.php" class="bg-gray-400 text-white px-4 py-2 rounded-lg">Batal</a>
            </div>
        </form>
    </div>
</body>
</html>