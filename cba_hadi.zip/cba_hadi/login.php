<?php
session_start();
require_once 'koneksi.php';

$error = '';

// Otomatis sinkronisasi akun default agar login selalu sukses
$pass_hash = password_hash('12345', PASSWORD_DEFAULT);
$cek = mysqli_query($koneksi, "SELECT * FROM users WHERE username = 'admin1'");
if (mysqli_num_rows($cek) === 0) {
    mysqli_query($koneksi, "INSERT INTO users (username, password, role) VALUES 
        ('admin1', '$pass_hash', 'admin'),
        ('petugas1', '$pass_hash', 'petugas'),
        ('user1', '$pass_hash', 'user')");
} else {
    mysqli_query($koneksi, "UPDATE users SET password = '$pass_hash' WHERE username IN ('admin1', 'petugas1', 'user1')");
}

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        
        if (password_verify($password, $row['password'])) {
            $_SESSION['id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['role'];

            // LEMPAR KE SATU HALAMAN UTAMA YANG SAMA
            header("Location: admin.php");
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak ditemukan!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login System Multi Role</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 flex items-center justify-center min-h-screen">
    <div class="w-full max-w-md bg-white p-8 rounded-xl shadow-md">
        <h2 class="text-2xl font-bold text-center text-slate-800 mb-2">Silakan Login</h2>
        <p class="text-xs text-center text-slate-400 mb-6">Bisa coba login: admin1, petugas1, atau user1 (Pass: 12345)</p>
        
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-sm">
                <?= $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-4">
                <label class="block text-slate-700 text-sm font-semibold mb-2">Username</label>
                <input type="text" name="username" required class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div class="mb-6">
                <label class="block text-slate-700 text-sm font-semibold mb-2">Password</label>
                <input type="password" name="password" required class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <button type="submit" name="login" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-lg transition duration-200">Login</button>
        </form>
    </div>
</body>
</html>
